package com.capgemini.capstore.dto;


import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name = "bookstore_customer")
public class Customer
{

	@Id
	@Column(name = "customerId")
	@NotNull
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int customerId;
	
	@Column(name = "customerName")
	@Size(min=8,max=30)
	@NotNull
	private String customerName;
	
	@Column(name = "email")
	@Size(min=10,max=64)
	@NotNull
	private String email;
	
	@Column(name = "password")
	@Size(min=8,max=16)
	@NotNull
	private String password;

	@Column(name = "mobileNo")
	@Size(min=10,max=15)
	@NotNull
	private String customerMobileNumber;
	
	@Column(name = "address")
	@Size(min=10,max=128)
	private String customerAddress;
	
	@Column(name = "city")
	@Size(min=3,max=32)
	@NotNull
	private String city;
	
	@Column(name = "pincode")
	@Size(min=3,max=24)
	@NotNull
	private String customerPincode;
 
	@Column(name = "country")
	@Size(min=3,max=64)
	@NotNull
	private String country;

	@Column(name="registerDate")
	@Temporal(TemporalType.DATE)
	private Date registerDate;
	
	@OneToMany
	@JoinTable
	(
			name="CustomerOrders",
            joinColumns = @JoinColumn( name="customerId"),
            inverseJoinColumns = @JoinColumn( name="orderId")
	)
	private List<Orders> orders= new ArrayList<>();

	@OneToMany
	@JoinTable
	(
			name="customerReview"
			,joinColumns=@JoinColumn(name="customerId")
			,inverseJoinColumns=@JoinColumn(name="reviewId")
	)
	private List<CustomerReview> reviews= new ArrayList<>();
	
	public Customer()
	{
		super();
	}

	public Customer(int customerId, String customerName, String email, String password, String customerMobileNumber,
			String customerAddress, String city, String customerPincode, String country, Date registerDate,
			Orders orders, CustomerReview reviews) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.email = email;
		this.password = password;
		this.customerMobileNumber = customerMobileNumber;
		this.customerAddress = customerAddress;
		this.city = city;
		this.customerPincode = customerPincode;
		this.country = country;
		this.registerDate = registerDate;
		this.orders.add(orders);
		this.reviews.add(reviews);
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getCustomerMobileNumber() {
		return customerMobileNumber;
	}

	public void setCustomerMobileNumber(String customerMobileNumber) {
		this.customerMobileNumber = customerMobileNumber;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCustomerPincode() {
		return customerPincode;
	}

	public void setCustomerPincode(String customerPincode) {
		this.customerPincode = customerPincode;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public Date getRegisterDate() {
		return registerDate;
	}

	public void setRegisterDate(Date registerDate) {
		this.registerDate = registerDate;
	}

	public List<Orders> getOrders() {
		return orders;
	}

	public void setOrders(Orders orders) {
		this.orders.add(orders);
	}

	public List<CustomerReview> getReviews() {
		return reviews;
	}

	public void setReviews(CustomerReview reviews) {
		this.reviews.add(reviews);
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", email=" + email
				+ ", password=" + password + ", customerMobileNumber=" + customerMobileNumber + ", customerAddress="
				+ customerAddress + ", city=" + city + ", customerPincode=" + customerPincode + ", country=" + country
				+ ", registerDate=" + registerDate + ", orders=" + orders + ", reviews=" + reviews + "]";
	}

	
	
	
}


