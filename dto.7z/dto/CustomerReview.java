package com.capgemini.capstore.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;

@Entity
@Table(name = "Review")
public class CustomerReview {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "reviewId")
	private int id;
	
	@Column(name = "rating")
	@Size(min=1,max=5)
	private int rating;
	
	@Column(name="headline")
	@Size(min=20,max=128)
	private String headline;

	@Column(name="comment")
	@Size(min=100,max=300)
	private String comment;
	
	@Column(name="reviewDate")
	@Temporal(TemporalType.DATE)
	private Date reviewDate;

	@ManyToOne
	@JoinTable
	(
			name="customerReview"
			,joinColumns=@JoinColumn(name="reviewId")
			,inverseJoinColumns=@JoinColumn(name="customerId")
	)
	private List<Customer> customer=new ArrayList<>();
	
	@ManyToOne
	@JoinTable(name="bookReview"
			,joinColumns=@JoinColumn(name="reviewId")
			,inverseJoinColumns= @JoinColumn(name="bookId")
			)
	private List<BookInfo> books=new ArrayList<>(); 
	

}
