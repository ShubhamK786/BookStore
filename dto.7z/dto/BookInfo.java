package com.capgemini.capstore.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name="bookstore_bookInfo")
public class BookInfo 
{
	@Id
	@Column(name = "bookId")
	@GeneratedValue(strategy = GenerationType.AUTO)
	@NotNull
	private int bookId;
	

	@Column(name = "title")
	@Size(min=10,max=128)
	@NotNull
	private String title;
	
	@Column(name = "author")
	@Size(min=5,max=64)
	@NotNull
	private String author;
	
	@Column(name = "description")
	@Size(min=200,max=2000)
	@NotNull
	private String description;
	
	@Column(name = "isbnNo")
	@Size(min=10,max=15)
	@NotNull
	private String isbnNo;
	
	@Column(name = "imageUrl")
	@NotNull
	private String url;
	
	@Column(name = "price")
	@NotNull
	private float price;
	
	@Column(name="publishedDate")
	@Temporal(TemporalType.DATE)
	private Date publishedDate;
	
	@OneToMany
	@JoinTable(name="bookReview"
	,joinColumns=@JoinColumn(name="bookId")
	,inverseJoinColumns= @JoinColumn(name="reviewId")
	)
	private List<CustomerReview> reviews = new ArrayList<>();
	
	
	@Column(name="lastUpdated")
	@Temporal(TemporalType.DATE)
	private Date lastUpdated;

	public BookInfo() 
	{
		super();
	}

	public BookInfo(int bookId, String title, String author, String description, String isbnNo, String url, float price,
			Date publishedDate, CustomerReview reviews, Date lastUpdated) {
		super();
		this.bookId = bookId;
		this.title = title;
		this.author = author;
		this.description = description;
		this.isbnNo = isbnNo;
		this.url = url;
		this.price = price;
		this.publishedDate = publishedDate;
		this.reviews.add(reviews);
		this.lastUpdated = lastUpdated;
	}

	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getIsbnNo() {
		return isbnNo;
	}

	public void setIsbnNo(String isbnNo) {
		this.isbnNo = isbnNo;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public Date getPublishedDate() {
		return publishedDate;
	}

	public void setPublishedDate(Date publishedDate) {
		this.publishedDate = publishedDate;
	}

	public List<CustomerReview> getReviews() {
		return reviews;
	}

	public void setReviews(CustomerReview reviews) {
		this.reviews.add(reviews);
	}

	public Date getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	@Override
	public String toString() {
		return "BookInfo [bookId=" + bookId + ", title=" + title + ", author=" + author + ", description=" + description
				+ ", isbnNo=" + isbnNo + ", url=" + url + ", price=" + price + ", publishedDate=" + publishedDate
				+ ", reviews=" + reviews + ", lastUpdated=" + lastUpdated + "]";
	}

	
	
}
