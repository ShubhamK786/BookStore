package com.capgemini.capstore.dto;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="bookstore_Cart")
public class Cart
{
	@Id
	@Column(name="cartId")
	private String cartId;
	
	@OneToOne
	private Customer customer;
	
	@OneToMany
	@JoinTable
	(
			name="CartBooks",
            joinColumns = @JoinColumn( name="cartID"),
            inverseJoinColumns = @JoinColumn( name="BookID")
	)
	private List<BookInfo> books = new ArrayList<>(); 	
	
	public Cart() 
	{
		super();
	}

	public Cart(String cartId, Customer customer, BookInfo books) {
		super();
		this.cartId = cartId;
		this.customer = customer;
		this.books.add(books);
	}

	public String getCartId() {
		return cartId;
	}

	public void setCartId(String cartId) {
		this.cartId = cartId;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public List<BookInfo> getBooks() {
		return books;
	}

	public void setBooks(BookInfo books) {
		this.books.add(books);
	}

	@Override
	public String toString() {
		return "Cart [cartId=" + cartId + ", customer=" + customer + ", books=" + books + "]";
	}
	
	
	
}
