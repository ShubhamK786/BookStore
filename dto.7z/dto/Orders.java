package com.capgemini.capstore.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name="orders")
public class Orders
{
	@Id
	@Column(name="orderId",length=10)
	private String orderId;
	
	@OneToMany
	@JoinTable
	(
			name="OrdersBooks",
            joinColumns = @JoinColumn( name="orderID"),
            inverseJoinColumns = @JoinColumn( name="bookID")
	)
	private List<BookInfo> books = new ArrayList<>();
	 
	@Column(name="recipentName")
	@Size(min=8,max=30)
	@NotNull
	private String recipentName;
	
	@Column(name="recipentPhoneNo")
	@Size(min=10,max=15)
	@NotNull
	private String recipentPhone;
	
	@Column(name = "streetAddress")
	@Size(min=10,max=128)
	private String StreetAddress;
	
	@Column(name = "city")
	@Size(min=3,max=32)
	@NotNull
	private String city;
	
	@Column(name="zipcode")
	@Size(min=3,max=24)
	@NotNull
	private String zipcode;
	
	
	@Column(name="country")
	@Size(min=3,max=64)
	@NotNull
	private String country;
	
	@Column(name="quantity")
	private int quantity;
	
	@Column(name="subtotal")
	private float subtotal;
	
	@Column(name="total")
	private float total;
	
	@Column(name="status")
	private String status;
	
	@Column(name="paymentMethod")
	private final String paymentMethod= "CashOnDelivery"; 
	
	@ManyToOne
	private Customer customer;
	
	@Column(name="orderDate",length=50)
	@Temporal(TemporalType.DATE)
	private Date orderDate;

	public Orders() {
		super();
	}

	public Orders(String orderId, BookInfo books, String recipentName, String recipentPhone, String streetAddress,
			String city, String zipcode, String country, int quantity, float subtotal, float total, String status,
			Customer customer, Date orderDate) {
		super();
		this.orderId = orderId;
		this.books.add(books);
		this.recipentName = recipentName;
		this.recipentPhone = recipentPhone;
		StreetAddress = streetAddress;
		this.city = city;
		this.zipcode = zipcode;
		this.country = country;
		this.quantity = quantity;
		this.subtotal = subtotal;
		this.total = total;
		this.status = status;
		this.customer = customer;
		this.orderDate = orderDate;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public List<BookInfo> getBooks() {
		return books;
	}

	public void setBooks(BookInfo books) {
		this.books.add(books);
	}

	public String getRecipentName() {
		return recipentName;
	}

	public void setRecipentName(String recipentName) {
		this.recipentName = recipentName;
	}

	public String getRecipentPhone() {
		return recipentPhone;
	}

	public void setRecipentPhone(String recipentPhone) {
		this.recipentPhone = recipentPhone;
	}

	public String getStreetAddress() {
		return StreetAddress;
	}

	public void setStreetAddress(String streetAddress) {
		StreetAddress = streetAddress;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public float getSubtotal() {
		return subtotal;
	}

	public void setSubtotal(float subtotal) {
		this.subtotal = subtotal;
	}

	public float getTotal() {
		return total;
	}

	public void setTotal(float total) {
		this.total = total;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public String getPaymentMethod() {
		return paymentMethod;
	}

	@Override
	public String toString() {
		return "Orders [orderId=" + orderId + ", books=" + books + ", recipentName=" + recipentName + ", recipentPhone="
				+ recipentPhone + ", StreetAddress=" + StreetAddress + ", city=" + city + ", zipcode=" + zipcode
				+ ", country=" + country + ", quantity=" + quantity + ", subtotal=" + subtotal + ", total=" + total
				+ ", status=" + status + ", paymentMethod=" + paymentMethod + ", customer=" + customer + ", orderDate="
				+ orderDate + "]";
	}
	
	
	
}
